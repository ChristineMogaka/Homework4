/******************************************
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/
#include "Movies.h"
Movies::Movies() {}
Movies::~Movies() {}

void Movies::update()
{

    string mov_id;
    cout << "Enter Movie ID to Update: ";
    cin >> mov_id;
    Movie *movie;

    vector<Movie>::iterator mov_iterator; // mov_collection iterator

    mov_iterator = find_if(movie_collection.begin(), movie_collection.end(), [&mov_id](Movie &mov)
                           { return mov.getId() == mov_id; });
    if (mov_iterator != movie_collection.end())
    {
        auto index = distance(movie_collection.begin(), mov_iterator);
        movie = &movie_collection.at(index);
        movie->edit();
    }
    else
    {
        cout << "Movie with id " << mov_id << " not Found!" << endl;
    }
}

void Movies::search()
{
    string move_name;
    cout << "Enter Movie Name to view details: ";
    cin >> move_name;
    bool found = false;
    for (auto mov : movie_collection)
    {
        if (mov.getTitle() == move_name)
        {
            printDetails(mov);
            found = true;
        }
    }
    if (!found)
    {
        cout << "Movie with Title " << move_name << " not Found!" << endl;
    }
}

void Movies::listOne()
{
    string mov_id;
    cout << "Enter Movie ID to view details: ";
    cin >> mov_id;

    vector<Movie>::iterator mov_iterator; // mov_collection iterator

    mov_iterator = find_if(movie_collection.begin(), movie_collection.end(), [&mov_id](Movie &mov)
                           { return mov.getId() == mov_id; });
    if (mov_iterator != movie_collection.end())
    {
        auto index = distance(movie_collection.begin(), mov_iterator);
        printDetails(movie_collection.at(index));
    }
    else
    {
        cout << "Movie with id " << mov_id << " not Found!" << endl;
    }
}

void Movies::add()
{
    unsigned int len0 = movie_collection.size();
    Movie newMovie = Movie();

    // add to collection
    this->movie_collection.push_back(newMovie);
    unsigned int len1 = movie_collection.size();

    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Movie Added Successfully\n";
    }
    else
    {
        cout << "Error adding Movie\n";
    }
}

void Movies::listAll()
{
    for (Movie mov : movie_collection)
    {
        mov.printDetails();
    }
}

void Movies::remove()
{
    string mov_id;
    cout << "Enter Movie ID to remove: ";
    cin >> mov_id;

    vector<Movie>::iterator mov_iterator; // mov_collection iterator

    mov_iterator = find_if(movie_collection.begin(), movie_collection.end(), [&mov_id](Movie &mov)
                           { return mov.getId() == mov_id; });
    if (mov_iterator != movie_collection.end())
    {
        auto index = distance(movie_collection.begin(), mov_iterator);
        movie_collection.erase(movie_collection.begin() + index);
        cout << "Movie with ID " << mov_id << " removed successfully" << endl;
    }
}

Movie Movies::findOne(string id)
{
    vector<Movie>::iterator mov_iterator; // mov_collection iterator

    mov_iterator = find_if(movie_collection.begin(), movie_collection.end(), [&id](Movie &mov)
                           { return mov.getId() == id; });
    if (mov_iterator != movie_collection.end())
    {
        auto index = distance(movie_collection.begin(), mov_iterator);
        return movie_collection.at(index);
    }
    else
    {
        cout << "Movie with id " << id << " not Found!" << endl;
        Movie mov = Movie();
        return mov;
    }
}

void Movies::printDetails(Movie mov)
{
    mov.printDetails();
}