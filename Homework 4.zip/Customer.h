/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include <iostream>
#include <string>
#include <limits>

using namespace std;

class Customer
{
private:
    string ID;
    string name;

public:
    unsigned int loan_count;
    Customer(string name, string id);
    Customer();
    ~Customer();
    void printDetails();
    void edit();

    string getStr(string prompt, unsigned int max, unsigned int min, unsigned short len);
    string getId();
    string getName();
    unsigned int getLoanCount();
    void setId();
    void setName();
    void setLoanCount();
    void updateCount(int count);
};