/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include <vector>
#include "Movie.h"
#include <algorithm>
using namespace std;

class Movies
{
private:
    vector<Movie> movie_collection;

public:
    Movies();
    ~Movies();
    void search();
    Movie findOne(string id);
    void listOne();
    void add();
    void listAll();
    void remove();
    void printDetails(Movie mov);
    void update();
};