#include <iostream>
#include <string>
#include <limits>
using namespace std;

class Game
{
protected:
    string title;
    string genre;
    string release_date;
    string studio;
    float cost;
    float r_cost; //replacement cost
    int rating;

public:
    Game();
    ~Game();
    Game(string title, string genre, string date, string studio, float cost, float r_cost, int rating);

    // Accessor
    string getTitle();
    string getGenre();
    string getDate();
    string getStudio();
    float getCost();
    float getR_Cost();
    int getRating();

    // muatator
    void setTitle(string title);
    void setGenre(string genre);
    void setDate(string date);
    void setStudio(string studio);
    void setCost(float cost);
    void setR_Cost(float r_cost);
    void setRating(int rating);

    // helper function
    virtual void printDetails();
    void edit();
};