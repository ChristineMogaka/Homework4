#include "EntItem.h"
#include <vector>
#include <limits>
class EntItems
{
private:
    vector<EntItem> entitems;

public:
    EntItems();
    ~EntItems();
    void add(EntItem *item);
    void remove(string id);
    void listAll();
    void listMovies();
    void listGames();
    EntItem findOne(string id);
    void listOne(string id);
    void edit(string id);
    void setStatus(string id, int state);
};