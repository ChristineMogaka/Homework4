#include <iostream>
#include <string>
#include <limits>
// print account operation choice
void printMenu();
string getStr(string prompt);
int getInt(string prompt);
float getFloat(string prompt);