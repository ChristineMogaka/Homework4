/******************************************
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include "Loans.h"
#include "Customers.h"
#include "functions.h"
#include "EntItems.h"

int main(int argc, char const *argv[])
{
    // initialize pointers to collection class objects to hold data
    Loans *loans = new Loans();
    Customers *customers = new Customers();
    EntItems *entitems = new EntItems();

    bool back = false; // aid in back navigation
    while (true)
    {
        // display prompt menu
        printMenu();
        unsigned int option;
        cin >> option;
        switch (option)
        {
        case 1:
            while (!back)
            {
                // prompt instruction
                printf("+--------------------------------------+\n");
                printf("| Customer Operations                  |\n");
                printf("| 1 : Add Customer Operation           |\n");
                printf("| 2 : Remove Customer Operations       |\n");
                printf("| 3 : List All Customers Operations    |\n");
                printf("| 4 : Search Customer Operations       |\n");
                printf("| 5 : Upadate Customer Operations      |\n");
                printf("| 0 : Go Back                          |\n");
                printf("+--------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                switch (customer_option)
                {
                case 1:
                    customers->add();
                    break;
                case 2:
                    customers->remove();
                    break;
                case 3:
                    customers->listAll();
                    break;
                case 4:
                    customers->findOne();
                    break;
                case 5:
                    customers->edit();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    break;
                }
            }
            back = false;
            break;
        case 2:
            while (!back)
            {
                printf("+---------------------------------------+\n");
                printf("| Loans Operations                      |\n");
                printf("| 1 :  Loan EntItem                     |\n");
                printf("| 2 :  Remove Loan Operations           |\n");
                printf("| 3 :  List All Loans                   |\n");
                printf("| 4 :  Search Loan By ID                |\n");
                printf("| 5 :  Update Loan                      |\n");
                printf("| 6 :  List Loans By Customer Loans     |\n");
                printf("| 7 :  List Loans By EntItem            |\n");
                printf("| 8 :  List Canceled Loans              |\n");
                printf("| 9 :  List Overdue Loans               |\n");
                printf("| 0 :  Go Back                          |\n");
                printf("+---------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                if (customer_option == 1)
                {
                    // customer id
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    string customer_id;
                    string entitem_id;
                    // float cost;
                    string loan_id;
                    string due_date;

                    cout << "Enter Customer ID: ";
                    getline(cin, customer_id);

                    Customer customer = (customers->search(customer_id));
                    // validate request
                    if ((customer.getId()).length() > 0)
                    {
                        if (customer.getLoanCount() >= 2)
                        {
                            puts("Already Reached Maximum Loan Limit");
                        }
                        else
                        {
                            cout << "Enter Item ID: ";
                            getline(cin, entitem_id);

                            cout << "Enter Loan ID: ";
                            getline(cin, loan_id);

                            cout << "Enter Due Date (dd/mm/yyyy): ";
                            getline(cin, due_date);

                            EntItem entitem = (entitems->findOne(entitem_id));

                            // validate request
                            if ((entitem.getID()).length() > 0)
                            {
                                int entitem_type = entitem.getType();
                                float cost;
                                if (entitem.getType() == 0)
                                {
                                    cost = entitem.Movie::getCost();
                                }

                                if (entitem.getType() == 1)
                                {
                                    cost = entitem.Game::getCost();
                                }

                                loans->add(entitem_id, customer_id, due_date, cost, loan_id, entitem_type);
                                customers->updateCount(customer_id, 1);
                                entitems->setStatus(entitem_id, 1);
                            }
                            else
                            {
                                puts("ITEM Does not Exist in Store.");
                            }
                        }
                    }
                    else
                    {
                        puts("Customer Does not Exist.");
                    }
                }
                if (customer_option == 2)
                {
                    string l_id = getStr("Enter Loan ID to Remove: ");
                    string it_id = loans->entId(l_id);
                    string c_id = loans->remove(l_id);

                    if (c_id != "null" && it_id != "null")
                    {
                        customers->updateCount(c_id, -1);
                        entitems->setStatus(it_id, 0);
                    }
                }
                if (customer_option == 3)
                {
                    loans->listAll();
                }
                if (customer_option == 4)
                {
                    loans->listOne();
                }
                if (customer_option == 5)
                {
                    loans->update();
                }
                if (customer_option == 6)
                {
                    loans->customerLoans();
                }
                if (customer_option == 7)
                {
                    int type;
                    cout << "Enter Item Type to View Loans (0-Movies 1-Games): ";
                    cin >> type;

                    if (type == 0)
                    {
                        loans->movieLoans();
                    }
                    else if (type == 1)
                    {
                        loans->gameLoans();
                    }
                    else
                    {
                        cout << "Invalid Input\n";
                    }
                }
                if (customer_option == 8)
                {
                    loans->canceledLoans();
                }
                if (customer_option == 9)
                {
                    loans->overDueLoans();
                }
                if (customer_option == 0)
                {
                    back = true;
                }
                else if (customer_option < 1 || customer_option > 11)
                {
                    puts("Invalid Choice");
                    back = false;
                }
            }
            break;
        case 3:
            while (!back)
            {
                printf("+---------------------------------------+\n");
                printf("| EntItems Operations                   |\n");
                printf("| 1 : Add EntItem Operation             |\n");
                printf("| 2 : Remove EntItem Operations         |\n");
                printf("| 3 : List All EntItems Operations      |\n");
                printf("| 4 : Search EntItem by ID              |\n");
                printf("| 5 : Update EntItem                    |\n");
                printf("| 6 : List Movies                       |\n");
                printf("| 7 : List Games                        |\n");
                printf("| 0 : Go Back                           |\n");
                printf("+--------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                if (customer_option == 1)
                {
                    string id;
                    int type;
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Enter Item ID: ";
                    getline(cin, id);

                    cout << "Enter Item Type (0-Movie 1-Game): ";
                    cin >> type;
                    if (type == 0)
                    {
                        EntItem *movie = new EntItem(id, type);
                        movie->Movie::setTitle(getStr("Enter Movie Title"));
                        movie->Movie::setDate(getStr("Enter Movie Release Date (mm/yyyy)"));
                        movie->Movie::setCost(getFloat("Enter Movie Cost"));
                        movie->Movie::setR_Cost(getFloat("Enter Replacement Cost"));
                        movie->Movie::setRating(getFloat("Enter Movie Rating"));
                        movie->Movie::setDuration(getStr("Enter Movie Duration(hh:mm)"));
                        entitems->add(movie);
                    }
                    if (type == 1)
                    {
                        EntItem *game = new EntItem(id, type);
                        game->Game::setTitle(getStr("Enter Game Title"));
                        game->Game::setDate(getStr("Enter Game Release Date (mm/yyyy)"));
                        game->Game::setGenre(getStr("Enter Game Genre"));
                        game->Game::setStudio(getStr("Enter Game Studio"));
                        game->Game::setCost(getFloat("Enter Game Cost"));
                        game->Game::setR_Cost(getFloat("Enter Replacement Cost"));
                        game->Game::setRating(getFloat("Enter Game Rating"));
                        entitems->add(game);
                    }
                }
                if (customer_option == 2)
                {
                    entitems->remove(getStr("Enter Item ID to remove"));
                }
                if (customer_option == 3)
                {
                    entitems->listAll();
                }
                if (customer_option == 4)
                {
                    entitems->listOne(getStr("Enter Item Id"));
                }
                if (customer_option == 5)
                {
                    entitems->edit(getStr("Enter Item ID"));
                }
                if (customer_option == 6)
                {
                    entitems->listMovies();
                }
                if (customer_option == 7)
                {
                    entitems->listGames();
                }
                if (customer_option == 0)
                {
                    back = true;
                }
                else if (customer_option < 0 || customer_option > 7)
                {
                    puts("Invalid Choice");
                    back = false;
                }
            }
            back = false;
            break;
        case 0:
            cout << "Thank you for using this program! Have a great day!\n";
            return true;
            break;
        default:
            puts("Invalid selection. Please enter choice 1 - 7.\n");
            break;
        }
    }
}

// print account operation choice
void printMenu()
{
    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Customer Operation               |\n");
    printf("| 2 : Loan Operations                  |\n");
    printf("| 3 : EntItem Operations               |\n");
    printf("| 0 : Exit Program                     |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
}

string getStr(string prompt)
{
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    string str;
    printf("Enter %s : ", prompt.c_str());
    getline(cin, str);
    return str;
}

float getFloat(string prompt)
{
    float flt;
    printf("Enter %s : ", prompt.c_str());
    cin >> flt;
    return flt;
}

int getInt(string prompt)
{
    int i;
    printf("Enter %s : ", prompt.c_str());
    cin >> i;
    return i;
}

// list accounts present in the banks
