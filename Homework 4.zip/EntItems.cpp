#include "EntItems.h"

EntItems::EntItems() {}
EntItems::~EntItems() {}

void EntItems::add(EntItem *newItem)
{
    int len0 = this->entitems.size();

    this->entitems.push_back(*newItem);
    int len1 = this->entitems.size();

    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Item Added Successfully\n";
    }
    else
    {
        cout << "Error adding Item\n";
    }
}

void EntItems::remove(string id)
{
    bool found = false;
    for (size_t i = 0; i < entitems.size(); i++)
    {
        EntItem tempObj = entitems.at(i);
        if (tempObj.getID() == id)
        {
            found = true;
            entitems.erase(entitems.begin() + i);
        }
    }

    if (found)
    {
        cout << "Item Deleted Successfully" << endl;
    }
    else
    {
        cout << "Item with id " << id << " not Found!" << endl;
    }
}

void EntItems::listAll()
{
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getType() == 0)
        {
            this->entitems.at(i).Movie::printDetails();
        }

        if (tempObj.getType() == 1)
        {
            this->entitems.at(i).Game::printDetails();
        }
    }
}

EntItem EntItems::findOne(string id)
{
    bool found = false;
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getID() == id)
        {
            found = true;
            return this->entitems.at(i);
            break;
        }
    }

    if (!found)
    {
        cout << "Item with id " << id << " not Found!" << endl;
    }
    EntItem item = EntItem();

    return item;
}

void EntItems::listOne(string id)
{
    bool found = false;
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getID() == id)
        {
            found = true;
            this->entitems.at(i).printDetails();
            break;
        }
    }

    if (!found)
    {
        cout << "Item with id " << id << " not Found!" << endl;
    }
}

void EntItems::edit(string id)
{
    bool found = false;
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getID() == id)
        {
            found = true;
            if (tempObj.getType() == 0)
            {
                this->entitems.at(i).Movie::edit();
            }

            if (tempObj.getType() == 1)
            {
                this->entitems.at(i).Game::edit();
                cout << "/n Item Edit Successfull";
            }
            break;
        }
    }

    if (!found)
    {
        cout << "Item with id " << id << " not Found!" << endl;
    }
}

void EntItems::listMovies()
{
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getType() == 0)
        {
            this->entitems.at(i).Movie::printDetails();
        }
    }
}

void EntItems::setStatus(string id, int state)
{
    bool found = false;
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getID() == id)
        {
            found = true;
            this->entitems.at(i).status = state;
            break;
        }
    }

    if (!found)
    {
        cout << "Item with id " << id << " not Found!" << endl;
    }
}
void EntItems::listGames()
{
    for (size_t i = 0; i < this->entitems.size(); i++)
    {
        EntItem tempObj = this->entitems.at(i);
        if (tempObj.getType() == 1)
        {
            this->entitems.at(i).Game::printDetails();
        }
    }
}