/******************************************
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/
#include "Loan.h"
#include <vector>
#include <limits>

class Loans
{
private:
    vector<Loan> loans;

public:
    Loans();
    ~Loans();
    void add(string movie_id, string customer_id, string date_due, float amount, string loan_id, int type);
    string remove(string id);
    void listOne();
    void listAll();
    void customerLoans();
    void movieLoans();
    void gameLoans();
    void overDueLoans();
    void canceledLoans();
    void update();
    string entId(string id);
    string getStr(string prompt);
};