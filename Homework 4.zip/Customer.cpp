/******************************************
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include "Customer.h"
#include <cmath>

// dummy constructor to fix bug
Customer::Customer()
{
}

// initialization constructor
Customer::Customer(string name, string id)
{
    this->name = name;
    this->ID = id;
    this->loan_count = 0;
}

Customer::~Customer()
{
}

// Utility Functions
void Customer::printDetails()
{
    printf("+--------------------------------------+\n");
    printf("| Name: %s\n", this->name.c_str());
    printf("| ID: %s\n", this->ID.c_str());
    printf("| Loaned Item: %d\n", this->loan_count);
    printf("+--------------------------------------+\n");
}

string Customer::getStr(string prompt, unsigned int min = 0, unsigned int max = 0, unsigned short len = 10)
{
    string str;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    if (max != 0 && min != 0)
    {
        printf("Enter %s (Min- %d Max- %d ): ", prompt.c_str(), min, max);
        getline(cin, str);
        if (str.length() > max || str.length() < min)
        {
            return "Invalid Input";
        }
        return str;
    }

    if (len > 0)
    {
        printf("Enter %s (Length- %d ): ", prompt.c_str(), len);
        getline(cin, str);
        if (str.length() != len)
        {
            return "Invalid Input";
        }
        return str;
    }

    return "Invalid Input";
}

void Customer::edit()
{
    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Name                        |\n");
    printf("| 2 : Edit ID                          |\n");
    printf("| 3 : Edit All                         |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;
    switch (option)
    {
    case 1:
        this->setName();
        break;
    case 2:
        this->setId();
        break;
    case 3:
        this->setName();
        this->setId();
        break;
    default:
        cout << "Invalid Option Chosen. No changes Made";
        break;
    }
}

//Accessor Methods
string Customer::getId()
{
    return this->ID;
}

string Customer::getName()
{
    return this->name;
}

unsigned int Customer::getLoanCount()
{
    return this->loan_count;
}

// Mutator Methods
void Customer::updateCount(int count)
{
    if (this->loan_count < 2)
    {
        this->loan_count += count;
    }
}

void Customer::setId()
{
    string ID = this->getStr("Customer ID", 4, 8, 0);
    if (ID != "Invalid Input")
    {
        this->ID = ID;
    }
    else
    {
        cout << "Invalid Input Detected. Change Ignored...\n";
    }
}

void Customer::setName()
{
    string name = this->getStr("Customer Name", 4, 40, 0);
    if (name != "Invalid Input")
    {
        this->name = name;
    }
    else
    {
        cout << "Invalid Input Detected.\n";
    }
}

void Customer::setLoanCount()
{
    int temp;
    cout << "Enter Count to Add: ";
    cin >> temp;

    if (temp >= -2 && temp <= 2)
    {
        this->loan_count += (int)temp;
        puts("Update Successful");
    }
    else
    {
        puts("Invalid Input");
    }
}