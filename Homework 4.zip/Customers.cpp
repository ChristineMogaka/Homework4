/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include "Customers.h"

void Customers::add()
{
    int len0 = this->customers.size();
    string name, id;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter Customer Name (Max 40 character): ";
    getline(cin, name);
    cout << "Enter Customer ID (Max 8 character): ";
    getline(cin, id);
    Customer newCustomer = Customer(name, id);
    this->customers.push_back(newCustomer);
    int len1 = this->customers.size();

    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Customer Added Successfully\n";
        this->count++;
    }
    else
    {
        cout << "Error adding Customer\n";
    }
}

void Customers::updateCount(string id, int count)
{
    bool found = false;
    for (size_t i = 0; i < customers.size(); i++)
    {
        Customer *tempObj = &customers.at(i);
        if (tempObj->getId() == id)
        {
            found = true;
            tempObj->updateCount(count);
        }
    }

    if (found)
    {
        cout << "Customer Deleted Successfully" << endl;
    }
    else
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}

void Customers::remove()
{
    string id;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << " Enter Customer ID:";
    getline(cin, id);
    bool found = false;
    for (size_t i = 0; i < customers.size(); i++)
    {
        Customer tempObj = customers.at(i);
        if (tempObj.getId() == id)
        {
            found = true;
            customers.erase(customers.begin() + i);
        }
    }

    if (found)
    {
        cout << "Customer Deleted Successfully" << endl;
    }
    else
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}

void Customers::findOne()
{
    string id;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << " Enter Customer ID:";
    getline(cin, id);
    bool found = false;
    for (size_t i = 0; i < this->customers.size(); i++)
    {
        Customer tempObj = this->customers.at(i);
        if (tempObj.getId() == id)
        {
            found = true;
            this->customers.at(i).printDetails();
            break;
        }
    }

    if (!found)
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}

void Customers::listAll()
{
    for (size_t i = 0; i < customers.size(); i++)
    {
        customers.at(i).printDetails();
    }
}

Customer Customers::search(string id)
{
    for (size_t i = 0; i < this->customers.size(); i++)
    {
        Customer tempObj = this->customers.at(i);
        if (tempObj.getId() == id)
        {
            return this->customers.at(i);
        }
    }

    Customer customer = Customer();
    return customer;
}

void Customers::edit()
{
    string id;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << " Enter Customer ID To Edit:";
    getline(cin, id);
    bool found = false;
    for (size_t i = 0; i < customers.size(); i++)
    {
        Customer *tempObj = &customers.at(i);
        if (tempObj->getId() == id)
        {
            found = true;
            tempObj->edit();
        }
    }

    if (found)
    {
        cout << "Customer Upadated Successfully\n"
             << endl;
    }
    else
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}