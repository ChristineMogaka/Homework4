#include "Game.h"

Game::Game() {}
Game::~Game() {}
Game::Game(string title, string genre, string date, string studio, float cost, float r_cost, int rating)
{
    this->title = title;
    this->genre = genre;
    this->release_date = date;
    this->studio = studio;
    this->rating = rating;
    this->cost = cost;
    this->r_cost = r_cost;
}

//getters
float Game::getCost()
{
    return this->cost;
}

float Game::getR_Cost()
{
    return this->r_cost;
}

string Game::getStudio()
{
    return this->studio;
}

string Game::getTitle()
{
    return this->title;
}

string Game::getGenre()
{
    return this->genre;
}

string Game::getDate()
{
    return this->release_date;
}

int Game::getRating()
{
    return this->rating;
}

// mutators
void Game::setCost(float cost)
{
    this->cost = cost;
}

void Game::setR_Cost(float cost)
{
    this->r_cost = cost;
}

void Game::setStudio(string studio)
{
    this->studio = studio;
}

void Game::setTitle(string title)
{
    this->title = title;
}

void Game::setGenre(string genre)
{
    this->genre = genre;
}

void Game::setDate(string date)
{
    this->release_date = date;
}

void Game::setRating(int rating)
{
    this->rating = rating;
};

// utitlity functions
void Game::printDetails()
{
    printf("+--------------------------------------+\n");
    printf("| Title: %s\n", this->title.c_str());
    printf("| Genre: %s\n", this->genre.c_str());
    printf("| Studio: %s\n", this->studio.c_str());
    printf("| Release Date: %s\n", this->release_date.c_str());
    printf("| Cost: %.2f\n", this->cost);
    printf("| Replacing Cost: %.2f\n", this->r_cost);
    printf("| Rating: %d\n", this->rating);
    printf("+--------------------------------------+\n");
}

void Game::edit()
{

    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Title                       |\n");
    printf("| 2 : Edit Genre                       |\n");
    printf("| 3 : Edit Rating.                     |\n");
    printf("| 4 : Edit Cost.                       |\n");
    printf("| 5 : Edit Replacing Cost              |\n");
    printf("| 6 : Edit Release Date.               |\n");
    printf("| 7 : Edit Studio.                     |\n");
    printf("| 8 : Edit All                         |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;

    {
        if (option == 1)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter Game Title: ";
            string str;
            getline(cin, str);
            this->setTitle(str);
        }
        if (option == 2)
        {
            cout << "Enter Game Genre: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            string str;
            getline(cin, str);
            this->setGenre(str);
        }

        if (option == 3)
        {
            cout << "Enter Rating (0-5): ";
            int rating;
            cin >> rating;
            this->setRating(rating);
        }

        if (option == 4)
        {
            cout << "Enter Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setCost(cost);
        }
        if (option == 5)
        {
            cout << "Enter Replacing Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setR_Cost(cost);
        }
        if (option == 6)
        {
            cout << "Enter Release Date (mm/yyyy): ";
            string str;
            cin >> str;
            this->setDate(str);
        }
        if (option == 7)
        {
            cout << "Enter Release Studio: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            string str;
            getline(cin, str);
            this->setStudio(str);
        }
        if (option == 8)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter Game Title: ";
            string title;
            getline(cin, title);
            this->setTitle(title);

            cout << "Enter Game Genre: ";
            string genre;
            getline(cin, genre);
            this->setGenre(genre);

            cout << "Enter Rating (0-5): ";
            int rating;
            cin >> rating;
            this->setRating(rating);

            cout << "Enter Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setCost(cost);

            cout << "Enter Replacing Cost(dd.cc): ";
            float r_cost;
            cin >> r_cost;
            this->setR_Cost(r_cost);

            cout << "Enter Release Date (mm/yyyy): ";
            string date;
            getline(cin, date);
            this->setDate(date);

            cout << "Enter Release Studio: ";
            string studio;
            getline(cin, studio);
            this->setStudio(studio);
        }
        if (option < 1 || option > 8)
        {
            cout << "Invalid Option Chosen. No changes Made";
        }
    }
}