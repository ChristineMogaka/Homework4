#include <iostream>
#include <string>
#include <limits>

using namespace std;

class Movie
{
protected:
    string title;
    string release_date;
    float cost;
    float r_cost; //replacement cost
    int rating;
    string duration;

public:
    Movie();
    ~Movie();
    Movie(string title, string date, float cost, float r_cost, int rating, string duration);

    // Accessor

    string getDuration();
    string getTitle();
    string getGenre();
    string getDate();
    string getStudio();
    float getCost();
    float getR_Cost();
    int getRating();

    // muatator
    void setTitle(string title);
    void setGenre(string genre);
    void setDate(string date);
    void setStudio(string studio);
    void setCost(float cost);
    void setR_Cost(float r_cost);
    void setRating(int rating);
    void setDuration(string durations);

    // helper function
    virtual void printDetails();
    void edit();
};