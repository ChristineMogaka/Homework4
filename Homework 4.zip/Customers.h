/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/
#include "Customer.h"
#include <vector>
#include <algorithm>
#include <limits>
class Customers
{
private:
    vector<Customer> customers;

public:
    unsigned int count;
    void add();
    void remove();
    void edit();
    void findOne();
    void listAll();
    Customer search(string id);
    void updateCount(string id, int count);
};