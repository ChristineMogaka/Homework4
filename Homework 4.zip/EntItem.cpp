#include "EntItem.h"
EntItem::EntItem()
{

    this->status = 0;
}

EntItem::EntItem(string id, int type)
{
    this->id = id;
    this->type = type;
    this->status = 0;
}
EntItem::~EntItem() {}

ostream &operator<<(ostream &out, const EntItem &c)
{
    out << "EntIem Id: " << c.id;
    out << "EntItem Type" << c.types[c.type] << endl;
    return out;
}

void EntItem::setID(string id)
{
    this->id = id;
}

void EntItem::setType(int type)
{
    this->type = type;
}

void EntItem::setDate(string date)
{
    this->loan_date = date;
}

string EntItem::getID()
{
    return this->id;
}

int EntItem::getType()
{
    return this->type;
}

string EntItem::getDate()
{
    return this->loan_date;
}

int EntItem::getLoanDuration()
{
    return this->loan_duration;
}

int EntItem::getStatus()
{
    return this->status;
}

void EntItem::printDetails()
{
    if (this->type == 0)
    {
        printf("+--------------------------------------+\n");
        printf("| ID: %s\n", this->id.c_str());
        printf("| Type: %s\n", this->types[this->type].c_str());
        printf("| Status: %s\n", this->states[this->status].c_str());
        printf("| Title: %s\n", this->Movie::title.c_str());
        printf("| Release Date: %s\n", this->Movie::release_date.c_str());
        printf("| Cost: %.2f\n", this->Movie::cost);
        printf("| Replacing Cost: %.2f\n", this->Movie::r_cost);
        printf("| Rating: %d\n", this->Movie::rating);
        printf("+--------------------------------------+\n");
    }

    if (this->type == 1)
    {
        printf("+--------------------------------------+\n");
        printf("| ID: %s\n", this->id.c_str());
        printf("| Type: %s\n", this->types[this->type].c_str());
        printf("| Status: %s\n", this->states[this->status].c_str());
        printf("| Title: %s\n", this->Game::title.c_str());
        printf("| Genre: %s\n", this->Game::genre.c_str());
        printf("| Studio: %s\n", this->Game::studio.c_str());
        printf("| Release Date: %s\n", this->Game::release_date.c_str());
        printf("| Cost: %.2f\n", this->Game::cost);
        printf("| Replacing Cost: %.2f\n", this->Game::r_cost);
        printf("| Rating: %d\n", this->Game::rating);
        printf("+--------------------------------------+\n");
    }
}