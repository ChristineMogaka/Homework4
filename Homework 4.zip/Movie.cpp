#include "Movie.h"

Movie::Movie() {}
Movie::~Movie() {}
Movie::Movie(string title, string date, float cost, float r_cost, int rating, string duration)
{
    this->title = title;
    this->release_date = date;
    this->rating = rating;
    this->cost = cost;
    this->r_cost = r_cost;
    this->duration = duration;
}

//getters
float Movie::getCost()
{
    return this->cost;
}

float Movie::getR_Cost()
{
    return this->r_cost;
}

string Movie::getTitle()
{
    return this->title;
}

string Movie::getDate()
{
    return this->release_date;
}

int Movie::getRating()
{
    return this->rating;
}

string Movie::getDuration()
{
    return this->duration;
}
// mutators
void Movie::setCost(float cost)
{
    this->cost = cost;
}

void Movie::setR_Cost(float cost)
{
    this->r_cost = cost;
}

void Movie::setTitle(string title)
{
    this->title = title;
}

void Movie::setDate(string date)
{
    this->release_date = date;
}

void Movie::setRating(int rating)
{
    this->rating = rating;
};

void Movie::setDuration(string duration)
{
    this->duration = duration;
}
// utitlity functions
void Movie::printDetails()
{
    printf("+--------------------------------------+\n");
    printf("| Title: %s\n", this->title.c_str());
    printf("| Release Date: %s\n", this->release_date.c_str());
    printf("| Duration: %s\n", this->duration.c_str());
    printf("| Cost: %.2f\n", this->cost);
    printf("| Replacing Cost: %.2f\n", this->r_cost);
    printf("| Rating: %d\n", this->rating);
    printf("+--------------------------------------+\n");
}

void Movie::edit()
{

    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Title                       |\n");
    printf("| 2 : Edit Rating.                     |\n");
    printf("| 3 : Edit Cost.                       |\n");
    printf("| 4 : Edit Replacing Cost              |\n");
    printf("| 5 : Edit Release Date.               |\n");
    printf("| 6 : Edit Movie Duration.             |\n");
    printf("| 7 : Edit All                         |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;

    {
        if (option == 1)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter Movie Title: ";
            string str;
            getline(cin, str);
            this->setTitle(str);
        }

        if (option == 2)
        {
            cout << "Enter Rating (0-5): ";
            int rating;
            cin >> rating;
            this->setRating(rating);
        }

        if (option == 3)
        {
            cout << "Enter Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setCost(cost);
        }
        if (option == 4)
        {
            cout << "Enter Replacing Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setR_Cost(cost);
        }
        if (option == 5)
        {
            cout << "Enter Release Date (mm/yyyy):";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            string str;
            getline(cin, str);
            this->setDate(str);
        }

        if (option == 5)
        {
            cout << "Enter Duration (hh:mm): ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            string str;
            getline(cin, str);
            this->setDuration(str);
        }

        if (option == 7)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter Movie Title: ";
            string title;
            getline(cin, title);
            this->setTitle(title);

            cout << "Enter Rating (0-5): ";
            int rating;
            cin >> rating;
            this->setRating(rating);

            cout << "Enter Cost(dd.cc): ";
            float cost;
            cin >> cost;
            this->setCost(cost);

            cout << "Enter Replacing Cost(dd.cc): ";
            float r_cost;
            cin >> r_cost;
            this->setR_Cost(r_cost);

            cout << "Enter Release Date (mm/yyyy): ";
            string date;
            getline(cin, date);
            this->setDate(date);

            cout << "Enter Duration (hh:mm): ";
            string durat;
            getline(cin, durat);
            this->setDuration(durat);
        }
        if (option < 1 || option > 7)
        {
            cout << "Invalid Option Chosen. No changes Made";
        }
    }
}