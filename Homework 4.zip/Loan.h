/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <limits>

using namespace std;

class Loan
{
private:
    string loan_id;
    string entitem_id;
    string customer_id;
    string due_date;
    string statuses[4] = {"Overdue", "Canceled", "Active"};
    unsigned int status;
    float amount;

public:
    Loan(string entitem_id, string customer_id, string date_due, float amount, string loan_id);
    ~Loan();
    int itemType;

    // accesor methods
    string getLoanID();
    string getCustomerId();
    string getDueDate();
    string getEntItemId();
    unsigned int getStatus();
    float getAmount();

    //mutator methods
    void setAmount(float amount);
    void setLoanID();
    void setCustomerId();
    void setDueDate();
    void setEntItemId();
    void setStatus();

    //utility functions
    void printDetails();
    void edit();
    string getStr(string prompt);
};