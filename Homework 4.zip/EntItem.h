#include <iostream>
#include <string>
#include "Movie.h"
#include "Game.h"
#include <limits>
using namespace std;

class EntItem : public Game, public Movie
{
private:
    string id;
    int type;
    int loan_duration;
    string loan_date;
    string types[2] = {"Movie", "Game"};
    string states[3] = {"In", "Out", "Lost"};

public:
    int status;
    EntItem();
    EntItem(string id, int type);
    ~EntItem();
    friend ostream &operator<<(ostream &os, const EntItem &dt);

    void setID(string id);
    void setType(int type);
    void setDate(string date);

    string getID();
    int getType();
    string getDate();
    int getLoanDuration();
    int getStatus();

    void printDetails() override;
};