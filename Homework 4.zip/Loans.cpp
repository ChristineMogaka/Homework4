/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1045 – PROJECT 1				* *
 * * NAME: 								* *
 * * EUID:								* *
 * * DATE:								* *
 * * EMAIL:								* *
 * ***************************************/
#include "Loans.h"

Loans::Loans() {}

void Loans::add(string entitem_id, string customer_id, string date_due, float amount, string loan_id, int type)
{
    unsigned int len0 = loans.size();
    Loan newLoan = Loan(entitem_id, customer_id, date_due, amount, loan_id);
    newLoan.itemType = type;
    this->loans.push_back(newLoan);
    unsigned int len1 = loans.size();

    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Loan Added Successfully\n";
        puts("\n");
    }
    else
    {
        cout << "Error adding Loan\n";
        puts("\n");
    }
}

void Loans::listAll()
{
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);

        loan.printDetails();
        puts("\n");
    }
}

void Loans::listOne()
{
    string loan_id = this->getStr("Loan ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getLoanID() == loan_id)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Loan ID: " << loan_id << endl;
        puts("\n");
    }
}

void Loans::update()
{
    string loan_id = this->getStr("Loan ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan *loan = &loans.at(i);
        if (loan->getLoanID() == loan_id)
        {
            loan->edit();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Loan ID: " << loan_id << endl;
        puts("\n");
    }
}

string Loans::remove(string id)
{
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan tempObj = loans.at(i);
        if (tempObj.getLoanID() == id)
        {
            loans.erase(loans.begin() + i);
            cout << "Loan Deleted Successfully" << endl;
            return tempObj.getCustomerId();
        }
    }

    cout << "Loan with ID " << id << " not Found!" << endl;
    return "null";
}

void Loans::customerLoans()
{
    string customer_id = this->getStr("Customer ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getCustomerId() == customer_id)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found fo Customer ID: " << customer_id << endl;
        puts("\n");
    }
}

void Loans::gameLoans()
{
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.itemType == 1)
        {
            loan.printDetails();
        }
    }
    cout << "No Loan Found for Games: " << endl;
    puts("\n");
}

void Loans::movieLoans()
{
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.itemType == 0)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Movies: " << endl;
        puts("\n");
    }
}

void Loans::overDueLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 0)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Overdue Loan Found: " << endl;
        puts("\n");
    }
}

void Loans::canceledLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 1)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Canceled Loan Found: " << endl;
        puts("\n");
    }
}

string Loans::entId(string id)
{
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getLoanID() == id)
        {
            return loan.getEntItemId();
        }
    }
    cout << "No Loan Found for Loan ID: " << endl;
    return "null";
}

string Loans::getStr(string prompt)
{
    string str;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    printf("Enter %s : ", prompt.c_str());
    getline(cin, str);
    return str;
}